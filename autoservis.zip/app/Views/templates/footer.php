<style>
.footer {
    text-align: center;
    margin-bottom: 0%;
    background-color: #dc3545;
    width: 100%;
    height: 5%;
    color: white;
}

</style>
<h5 class="footer">Vytvořil: Peťa Rídl :3 </h5>
</body>
</html>


