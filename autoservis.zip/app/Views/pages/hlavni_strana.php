<style>
.obsah{
    float: center;
    width: 98%;
    height: 85%;
    margin-left: 1%;
}

p{
    line-height: 0,7;
}
.center {
  display: block;
  margin-left: 45%;
  margin-right: auto;
  
}
</style>
<div class="obsah">
<h1>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Etiam egestas wisi a erat. Sed ac dolor sit amet purus malesuada congue. Proin in tellus sit amet nibh dignissim sagittis. Aenean vel massa quis mauris vehicula lacinia. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
<img class="center img-fluid" src="<?php echo base_url()?>vlastni_soubory/img/felda.jpg" alt="felda">
</div>

