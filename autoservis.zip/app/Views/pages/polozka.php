<style>
.obsah{
    float: center;
    width: 98%;
    height: 85%;
    
}

</style>
<h3>Položka přidána!</h3>